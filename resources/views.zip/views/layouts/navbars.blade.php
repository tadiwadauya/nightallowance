@yield('navs')

@extends('layouts.styless')
@section('style')

<body class="hold-transition sidebar-mini layout-fixed">
